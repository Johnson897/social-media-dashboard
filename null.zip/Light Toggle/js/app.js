
	document.addEventListener('DOMContentLoaded', () => {

  const body=document.querySelector('body');
  const button=document.querySelector('button');
  const row= document.querySelector('.row');
   const row1= document.querySelector('#row1');
  let on=true;
  function light()
  {
    if (on==true)
    {
       body.classList.add("bg-dark") 
       body.classList.add("white")
       row.classList.add('black')
       row1.classList.add('black')
       button.innerHTML='Day-Mode'
       on=false;
    }
    else if(on==false)
    {
    	 body.classList.remove("bg-dark") 
       body.classList.remove("white")
       button.innerHTML='Dark-Mode'

       on=true;
    }
  }

button.addEventListener('click', light)
})